## OpenShift - Projects 101

In a newly deployed cluster (preferably) perform and answer the following instructions and questions, using CLI only

1. Login to the OpenShift cluster
2. List all the projects
3. Create a new project called 'neverland'
4. Check the overview status of the current project
