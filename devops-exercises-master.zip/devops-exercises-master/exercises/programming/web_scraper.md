## Web Scraper

1. Pick a web site to scrape
2. Using any language you would like, write a web scraper to save some data from the site you chose
3. Save the results to a database (doesn't matter which database, just pick one)


* Note: if you don't know which site to pick up have a look [here](http://toscrape.com)
