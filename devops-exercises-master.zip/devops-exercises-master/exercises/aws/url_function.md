## URL Function

Create a basic AWS Lambda function that will be triggered when you enter a URL in the browser
