## Jobs 101

1. Create a new job/pipeline
2. Make sure every time the job is triggered it prints the current date
