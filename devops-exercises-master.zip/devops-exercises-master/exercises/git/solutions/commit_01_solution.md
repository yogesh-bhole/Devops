## Git Commit 01 - Solution

```
mkdir my_repo && cd my_repo
git init
echo "hello_commit" > file
git add file
git commit -a -m "It's my first commit. Exciting!"
git log
```
